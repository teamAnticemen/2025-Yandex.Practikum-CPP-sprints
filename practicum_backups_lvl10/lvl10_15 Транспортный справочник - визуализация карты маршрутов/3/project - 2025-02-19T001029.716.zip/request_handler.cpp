#include "request_handler.h"
#include <algorithm>
#include <iostream>
#include <iomanip> // Для std::setprecision
#include <vector>

namespace stat_reader {

StatReader::StatReader(const transport_catalogue::TransportCatalogue& catalogue) : catalogue_(catalogue) {}
/*
Я не буду это переносить в json. Эта часть кода отвечает за обработку запросов stat_requests
Так же файл json_reader отвечает за обработку входных данных base_requests
Все остальные подкапотные дела связанные с json находятся в json.h и json.cpp
*/
void StatReader::ProcessQuery(const json::Node& query) const {
    const auto& query_map = query.AsMap();
    const std::string& type = query_map.at("type").AsString();
    int request_id = query_map.at("id").AsInt();

    json::Dict response;

    if (type == "Bus") {
        const std::string& bus_name = query_map.at("name").AsString();
        response = ProcessBusQuery(bus_name, request_id);
    } else if (type == "Stop") {
        const std::string& stop_name = query_map.at("name").AsString();
        response = ProcessStopQuery(stop_name, request_id);
    } else if (type == "Map") {
        response = ProcessMapQuery(request_id);
    } else {
        response = {
            {"request_id", json::Node(request_id)},
            {"error_message", json::Node("invalid query type")}
        };
    }

    json::Print(json::Node(response), std::cout, 0);
    std::cout << "\n";
}

//----- Bus -----
json::Dict StatReader::ProcessBusQuery(const std::string& bus_name, int request_id) const {
    const transport_catalogue::Bus* bus = catalogue_.FindBus(bus_name);

    if (!bus) {
        return {
            {"request_id", json::Node(request_id)},
            {"error_message", json::Node("not found")}
        };
    }

    transport_catalogue::BusInfo bus_info = catalogue_.GetBusInfo(bus_name, request_id);

    return {
        {"request_id", json::Node(bus_info.request_id)},
        {"curvature", json::Node(bus_info.curvature)},
        {"route_length", json::Node(bus_info.route_length)},
        {"stop_count", json::Node(bus_info.stop_count)},
        {"unique_stop_count", json::Node(bus_info.unique_stop_count)}
    };
}

//----- Stop -----
json::Dict StatReader::ProcessStopQuery(const std::string& stop_name, int request_id) const {
    const transport_catalogue::Stop* stop = catalogue_.FindStop(stop_name);

    if (!stop) {
        return {
            {"request_id", json::Node(request_id)},
            {"error_message", json::Node("not found")}
        };
    }

    const auto& buses = catalogue_.GetBusesByStop(stop_name);
    std::vector<json::Node> buses_array;
    for (const transport_catalogue::Bus* bus : buses) {
        buses_array.push_back(json::Node(bus->name));
    }

    return {
        {"request_id", json::Node(request_id)},
        {"buses", json::Node(buses_array)}
    };
}

//----- Map -----
json::Dict StatReader::ProcessMapQuery(int request_id) const {
    return {
        {"request_id", json::Node(request_id)},
        {"error_message", json::Node("map rendering not implemented")}
    };
}

} // namespace stat_reader