#include <iostream>
#include <string>
#include "transport_catalogue.h"
#include "json_reader.h"
#include "json.h"
#include <sstream>

std::string LoadDocumentFromStream(std::istream& input) {
    std::string input_json;
    int brace_count = 0; // Счетчик фигурных скобок
    char ch;

    while (input.get(ch)) {
        input_json += ch;

        if (ch == '{') {
            brace_count++;
        } else if (ch == '}') {
            brace_count--;
        }

        // Если число открытых и закрытых скобок совпало, завершаем чтение
        if (brace_count == 0) {
            break;
        }
    }

    return input_json;
}

int main() {
    transport_catalogue::TransportCatalogue catalogue;
    json_reader::JsonReader json_reader(catalogue);

    // Загружаем JSON-документ из стандартного ввода
    std::string input_json = LoadDocumentFromStream(std::cin);
    
     // Преобразуем строку в json::Document
    json::Document input_data = json::LoadJSON(input_json);

    // Загрузка данных в каталог
    json_reader.LoadData(input_data.GetRoot());

    // Обработка запросов и вывод информации
    const auto& stat_requests = input_data.GetRoot().AsMap().at("stat_requests").AsArray();
    json::Node responses = json_reader.ProcessRequests(stat_requests);

    // Вывод ответов
    json::Print(responses, std::cout, 4);
}